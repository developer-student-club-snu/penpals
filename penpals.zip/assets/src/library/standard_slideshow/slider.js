//TODO: Complete this library!
var slider = function()
{
    var class_used = "litico_lib_slider_u1";
    var representative_html =
        `<div class="${class_used}">` +
        `</div>`;
    var slider_obj = new Object();
    slider_obj.noOfElem = 0;
    slider_obj.elem = [];
    slider_obj.holder_id = "";
    slider_obj.resizes = false;

    function render_elem_html(background, content) {
        var render_html = "";
    }

    slider_obj.add_elem = function(args){
    }
}();